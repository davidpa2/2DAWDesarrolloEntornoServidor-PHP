<?php

require_once 'Conexion.php';
require_once '../Model/Juego.php';

class JuegoController {

    public static function mostrarJuegos() {
        try {
            $con = new Conexion();

            $result = $con->query("select * from juegos");

            while ($fila = $result->fetch()) {
                $juego = new Juego($fila->Nombre_juego, $fila->Nombre_consola, $fila->Anno, $fila->Precio, $fila->Alquilado, $fila->Imagen, $fila->descripcion);
                $juegos[] = $juego;
            }

            return $juegos;
            
        } catch (PDOException $e) {
            echo $e->getTraceAsString();
        }
    }
    
    public static function mostrarJuegosAlquilados() {
        try {
            $con = new Conexion();

            $result = $con->query("select * from juegos where Alquilado = 'SI';");

            while ($fila = $result->fetch()) {
                $juego = new Juego($fila->Nombre_juego, $fila->Nombre_consola, $fila->Anno, $fila->Precio, $fila->Alquilado, $fila->Imagen, $fila->descripcion);
                $juegos[] = $juego;
            }

            return $juegos;
            
        } catch (PDOException $e) {
            echo $e->getTraceAsString();
        }
    }

    public static function mostrarJuegosDisponibles() {
        try {
            $con = new Conexion();

            $result = $con->query("select * from juegos where Alquilado = 'NO';");

            while ($fila = $result->fetch()) {
                $juego = new Juego($fila->Nombre_juego, $fila->Nombre_consola, $fila->Anno, $fila->Precio, $fila->Alquilado, $fila->Imagen, $fila->descripcion);
                $juegos[] = $juego;
            }

            return $juegos;
            
        } catch (PDOException $e) {
            echo $e->getTraceAsString();
        }
    }
    
    public static function mostrarJuegosUsuario($dniUsuario) {
        try {
            $con = new Conexion();

            $result = $con->query("select * from juegos j join alquiler a where j.Codigo = a.Cod_juego and DNI_cliente = '" . $dniUsuario . "';");

            while ($fila = $result->fetch()) {
                $juego = new Juego($fila->Nombre_juego, $fila->Nombre_consola, $fila->Anno, $fila->Precio, $fila->Alquilado, $fila->Imagen, $fila->descripcion);
                $juegos[] = $juego;
            }

            return $juegos;
            
        } catch (PDOException $e) {
            echo $e->getTraceAsString();
        }
    }
}
