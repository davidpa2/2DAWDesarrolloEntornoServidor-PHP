<?php
require_once '../Model/Juego.php';
session_start();
if (isset($_POST['cerrarSesion'])) {
    session_unset();
    session_destroy();
}
?>

<html>
    <head>
        <title>Juego</title>
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
              integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
    </head>
    <body>
        <?php
        //require_once 'Navbar.php';
        //if (isset($_GET['juego'])){
            //$decodificar = json_decode($_GET['juego']);
            //echo json_decode($_GET['juego']);
            /*var_dump($decodificar->codigo);
            var_dump($decodificar);
            var_dump(json_decode($_GET['juego']));*/
            //echo $decodificar->getPrecio();
            //$juego = new Juego($decodificar->, $nombreConsola, $anno, $precio, $alquilado, $imagen, $descripcion)
            //echo $juego->getNombreJuego();
        //}
        //$juego = explode("patata", $_GET['juego']);
        //echo $juego[4];
        ?>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </body>
</html>
