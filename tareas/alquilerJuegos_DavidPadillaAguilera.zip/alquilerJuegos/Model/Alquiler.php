<?php

class Alquiler {
    protected $codJuego;
    protected $dniCliente;
    protected $fechaAlquiler;
    protected $fechaDevol;
    
    public function __construct($codJuego, $dniCliente) {
        $this->codJuego = $codJuego;
        $this->dniCliente = $dniCliente;
        $this->fechaAlquiler = date('Y\-m\-d', time());        
        $this->fechaDevol = date('Y\-m\-d',time() + 604800);
    }

    /**
     * GETTERS & SETTERS
     */
    public function getCodJuego() {
        return $this->codJuego;
    }

    public function getDniCliente() {
        return $this->dniCliente;
    }

    public function getFechaAlquiler() {
        return $this->fechaAlquiler;
    }

    public function getFechaDevol() {
        return $this->fechaDevol;
    }

    public function setCodJuego($codJuego): void {
        $this->codJuego = $codJuego;
    }

    public function setDniCliente($dniCliente): void {
        $this->dniCliente = $dniCliente;
    }

    public function setFechaAlquiler($fechaAlquiler): void {
        $this->fechaAlquiler = $fechaAlquiler;
    }

    public function setFechaDevol($fechaDevol): void {
        $this->fechaDevol = $fechaDevol;
    }
}