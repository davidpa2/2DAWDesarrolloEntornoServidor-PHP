<html>
    <head>
        <title>Agenda</title>
        <link href="agenda.css" rel="stylesheet" type="text/css" media="all"/>
    </head>
    <body>

        <?php
        require_once 'FuncionesAgenda.php';
        if (isset($_POST['guardar'])) {
            $agend = json_decode($_POST['agenda'], true);

            if (empty($_POST['nombre'])) {
                echo '<div class="error">El nombre está vacío</div>';
            } else {

                if (empty($_POST['numero'])) {

                    //if (isset($agend[$_POST['nombre']])) {
                    if (array_key_exists($_POST['nombre'], $agend)) {    
                        unset($agend[$_POST['nombre']]);
                    } else {
                        echo '<div class="error">' . $_POST['nombre'] . ' no está anotado en la agenda</div>';
                    }
                } else {

                        if (!empty($agend['nombre'])) {
                            echo '<div class="correcto">Contacto añadido a la agenda</div>';
                        } else {
                            echo '<div class="correcto">Contacto modificado correctamente</div>';         
                        }       
                        $agend[$_POST['nombre']] =  $_POST['numero'];
                        
                }
            }
            mostrarAgenda($agend);
        }
        ?>
        <div class="formulario">
            <form action="" method="POST">
                Nombre: <input type="text" name="nombre"><br>
                Número de teléfono:<input type="text" name="numero"><br>
                <input type="hidden" name="agenda" value=<?php if (isset($_POST['guardar'])) echo json_encode($agend); ?>>
                <input type="submit" name="guardar" value="Guardar">
            </form>
        </div>

    </body>
</html>
